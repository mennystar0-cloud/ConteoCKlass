// functions/index.js — Google Cloud Functions for Conteo CKLASS
// Node 20, CommonJS
const functions = require('firebase-functions');
const admin = require('firebase-admin');
const fetch = require('node-fetch');
const Papa = require('papaparse');

admin.initializeApp();
const db = admin.firestore();

// Helper: bulk upsert to catalog
async function upsertCatalogRows(rows, chunkSize=450) {
  const writer = db.bulkWriter();
  let total = 0;
  for (const row of rows) {
    // Normalize expected headers: model,color,talla,code,teorico
    const code = String(row.code || row.CODIGO || row.CODIGO_BARRAS || row.codigo || '').trim();
    if (!code) continue;
    const data = {
      model: String(row.model || row.MODELO || row.modelo || '').trim(),
      color: String(row.color || row.COLOR || row.colorway || '').trim(),
      talla: String(row.talla || row.TALLA || '').trim(),
      code,
      teorico: Number(row.teorico || row.TEORICO || row.existencias || 0)
    };
    writer.set(db.collection('catalog').doc(code), data, { merge: true });
    total++;
  }
  await writer.close(); // flush
  return total;
}

// HTTPS: Carga catálogo desde CSV público (Google Drive direct download o cualquier URL)
exports.loadCatalogFromCsv = functions.runWith({ timeoutSeconds: 540, memory: '2GiB' }).https.onRequest(async (req, res) => {
  try {
    const url = req.query.url || req.body.url;
    if (!url) return res.status(400).json({ error: "Falta ?url=" });
    const r = await fetch(url);
    if (!r.ok) throw new Error(`Fetch error ${r.status}`);
    const csv = await r.text();

    const parsed = await new Promise((resolve, reject) => {
      Papa.parse(csv, {
        header: true,
        skipEmptyLines: true,
        complete: results => resolve(results.data),
        error: reject
      });
    });

    const total = await upsertCatalogRows(parsed);
    res.json({ ok:true, total });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, error: String(e) });
  }
});

// Callable: Asignar rol (admin/supervisor/invitado)
exports.setRole = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Requiere auth');
  // solo admin
  const token = await admin.auth().verifyIdToken(context.auth.token);
  if (token.role !== 'admin') throw new functions.https.HttpsError('permission-denied', 'Solo admin');
  const { uid, role } = data;
  if (!uid || !role) throw new functions.https.HttpsError('invalid-argument', 'Falta uid/role');
  await admin.auth().setCustomUserClaims(uid, { role });
  return { ok:true };
});

// HTTPS: Consecutivo de folio por prefijo
exports.getNextFolio = functions.https.onRequest(async (req, res) => {
  try {
    const prefix = (req.query.prefix || req.body.prefix || 'C').toUpperCase();
    const ymd = new Date().toISOString().slice(0,10).replace(/-/g,'');
    const ref = db.collection('counters').doc(`folio-${prefix}-${ymd}`);
    const out = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      let n = 0;
      if (snap.exists) n = snap.data().n || 0;
      n++;
      tx.set(ref, { n }, { merge:true });
      return n;
    });
    const folio = `${prefix}-${ymd}-${String(out).padStart(3,'0')}`;
    res.json({ folio });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e) });
  }
});
